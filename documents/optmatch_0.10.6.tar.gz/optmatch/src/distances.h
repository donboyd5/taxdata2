#include <R.h>
#include <Rinternals.h>

#ifndef _DISTANCES_H_
#define _DISTANCES_H_

SEXP mahalanobisHelper(SEXP data, SEXP index, SEXP invScaleMat);

#endif
