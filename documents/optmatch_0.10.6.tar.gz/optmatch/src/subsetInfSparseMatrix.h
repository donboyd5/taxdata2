#include <R.h>

#ifndef _SUBSETISM_H_
#define _SUBSETISM_H_

#endif
