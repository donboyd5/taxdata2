#include <Rcpp.h>

#ifndef _ISM_H_
#define _ISM_H_

#endif
