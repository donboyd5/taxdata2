library(testthat)
library(optmatch)

test_check("optmatch")
