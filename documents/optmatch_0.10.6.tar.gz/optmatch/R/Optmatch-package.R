#' @useDynLib optmatch, .registration=TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom stats aggregate as.formula contr.poly cov formula get_all_vars mad model.frame model.matrix model.response na.omit na.pass optimize predict quantile sd terms terms.formula update update.formula
#' @importFrom utils getS3method methods
#' @importFrom methods is as new hasMethod callGeneric show validObject callNextMethod slot
NULL
#> NULL


NULL
